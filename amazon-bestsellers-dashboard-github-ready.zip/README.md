# Amazon Bestsellers Analytics Dashboard

A portfolio-ready data analysis project built with **NumPy, Pandas, Matplotlib, Seaborn, Plotly, and Streamlit**. It cleans and audits the Amazon Top-50 bestseller dataset, distinguishes real errors from meaningful recurring records, and turns the result into decision-focused insights.

## What this project demonstrates

- An analyst-first workflow: define the row grain before aggregating.
- Auditable cleaning with a before/after change log.
- Safe handling of repeated titles, ambiguous editions, zero prices, and outliers.
- Pandas `groupby`, `agg`, `nunique`, robust medians, correlations, and feature engineering.
- NumPy-based bucketing, conditions, transforms, and chart positioning.
- Interactive Plotly views plus Seaborn and Matplotlib statistical charts.
- A polished multi-page Streamlit dashboard with shared filters and CSV downloads.
- Automated tests and a GitHub Actions quality workflow.

## The key analytical decision

One row is a **bestseller-list record**, not a sale. The file contains 50 rows for each year from 2009 through 2019. A recurring title can therefore be valuable evidence of persistence. The cleaning pipeline removes only proven errors such as exact duplicate rows or invalid required records; it does **not** delete annual title repeats.

The dataset does not contain units sold, revenue, rank, format, or dated review history. The dashboard deliberately avoids sales claims and does not sum repeated review snapshots across years.

## Project structure

```text
amazon-bestsellers-dashboard/
├── streamlit_app.py              # Multi-page router and shared filters
├── app_pages/                    # Dashboard pages
├── src/                          # Cleaning, analytics, charts, and UI helpers
├── scripts/build_processed_data.py
├── data/
│   ├── raw/                      # Original file, unchanged
│   └── processed/                # Clean data, quality report, change log
├── reports/analysis_report.md    # Static findings and recommendations
├── docs/data_dictionary.md
├── tests/                        # Cleaning and analytical-grain tests
├── .streamlit/config.toml        # Native Streamlit theme
└── .github/workflows/            # CI quality checks
```

## Run locally

```bash
python -m venv .venv
```

Windows:

```bash
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run streamlit_app.py
```

macOS / Linux:

```bash
source .venv/bin/activate
pip install -r requirements.txt
streamlit run streamlit_app.py
```

Rebuild the processed files and run tests:

```bash
python scripts/build_processed_data.py
python -m unittest discover -s tests -v
```

## Publish to GitHub

```bash
git init
git add .
git commit -m "Build Amazon bestseller analytics dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Before making the repository public, confirm the original dataset's source and redistribution license. The MIT license in this repository covers the project code, not third-party data.

## Deploy on Streamlit Community Cloud

1. Push the project to a public GitHub repository.
2. In Streamlit Community Cloud, create a new app from that repository.
3. Set the entry point to `streamlit_app.py`.
4. Choose Python 3.12 and deploy. Dependencies are listed in `requirements.txt`.

## Headline results

- 550 source records, 100% complete, and no exact duplicate rows.
- 350 canonical titles and 246 canonical authors after controlled entity cleanup.
- 95 titles recur; 295 rows belong to recurring titles.
- 3 extra same-title/year records remain because their prices differ and likely represent editions or formats.
- 12 zero-price records remain flagged rather than guessed or imputed.
- 31 price, 17 review, and 21 rating IQR outlier rows are retained as analytically meaningful.
- The strongest persistence is 10 distinct years, reached by two titles.
- Fiction has higher median review engagement and a slightly higher average rating, while Non Fiction has more list records and a higher median price.
- Rating–review Spearman correlation is only `0.20`; popularity and satisfaction are not interchangeable.

See [the full analysis report](reports/analysis_report.md) for evidence, limitations, and recommendations.

## ملخص بالعربي

المشروع ينظف الداتا بدون حذف التكرار المفيد، لأن نفس الكتاب ممكن يظهر في قائمة أفضل 50 في أكثر من سنة. كل تعديل نصي له سجل قبل/بعد وسبب، والقيم المشكوك فيها مثل السعر صفر أو نفس العنوان والسنة بأسعار مختلفة تظل موجودة مع Flag واضح. التحليل يقيس الظهور في القائمة والتقييمات والمراجعات والسعر فقط، ولا يدّعي وجود بيانات مبيعات أو إيرادات.

