# Data Dictionary

## Clean core fields

| Field | Type | Description |
|---|---|---|
| `record_id` | integer | Stable sequential ID in the clean output. |
| `source_row` | integer | One-based row number from the raw CSV for auditability. |
| `title` | string | Cleaned canonical book title. Original column: `Name`. |
| `author` | string | Cleaned canonical author. |
| `user_rating` | float | Amazon user rating, validated to the 1–5 range. |
| `reviews` | integer | Review-count snapshot. Must not be summed across annual repeats. |
| `price` | integer | Listed price in dollars. Zero values are retained and flagged. |
| `year` | integer | Year in which the record appears in the annual list. |
| `genre` | string | `Fiction` or `Non Fiction`. |

## Quality flags

| Field | Type | Description |
|---|---|---|
| `is_zero_price` | boolean | Price equals zero and needs source verification. |
| `is_price_outlier` | boolean | Price is outside the 1.5 × IQR bounds. |
| `is_review_outlier` | boolean | Review count is outside the 1.5 × IQR bounds. |
| `is_rating_outlier` | boolean | Rating is outside the 1.5 × IQR bounds. |
| `is_title_year_duplicate` | boolean | Another record shares the title and year. Retained because price differs. |
| `is_truncated_text` | boolean | Title or author appears cut off or ends in an ellipsis. |

## Analytical features

| Field | Type | Description |
|---|---|---|
| `rating_band` | string | Rating category: exceptional, strong, solid, or below 4.0. |
| `price_band` | string | Zero/verify, budget, mid-range, or premium. |
| `engagement_segment` | string | Rating–review quadrant using dataset medians. |
| `review_log10` | float | Base-10 log of reviews for skew-resistant visualization. |
| `years_on_list` | integer | Number of distinct years the title appears. |
| `first_year` | integer | First observed list year for the title. |
| `last_year` | integer | Last observed list year for the title. |

## Grain rules

- Use the clean table for listing-level questions.
- Use `book_summary()` for one row per canonical title.
- Count `year` with `nunique` for persistence.
- Do not sum `reviews` across years; use a representative snapshot such as `max` or `median` per title.
- Use median price when outliers or zero-price ambiguity could distort the mean.

