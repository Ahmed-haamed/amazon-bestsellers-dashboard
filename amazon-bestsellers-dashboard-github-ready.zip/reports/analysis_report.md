# Analysis Report: Amazon Bestsellers 2009–2019

## Executive summary

The source is structurally complete but contains catalog-quality issues: encoding artifacts, entity spelling variants, possible text truncation, zero prices, and same-title/year records with different prices. None of the 550 records required deletion. The clean layer contains 350 canonical titles and 246 canonical authors.

The most important methodological finding is that this is an annual list dataset, not a transaction table. Repeated rows often represent continued list presence. In addition, 93 of 95 recurring titles keep exactly the same review count across their repeated records, strongly suggesting that reviews are a snapshot copied across years rather than a historical time series.

## Data quality findings

| Finding | Count | Likely cause | Decision |
|---|---:|---|---|
| Missing values | 0 | Source is complete | No imputation |
| Exact duplicate rows | 0 | No exact extraction duplicates | No rows removed |
| Encoding-affected records | 3 | Windows-1252 punctuation stored as control characters | Repaired deterministically |
| Verified alias changes | 9 | Punctuation, spacing, and title-capitalization variants | Mapped to canonical entities |
| Recurring titles | 95 | Annual Top-50 list persistence | Retained |
| Same title and year | 6 affected rows / 3 extras | Likely separate formats or editions | Retained and flagged |
| Zero prices | 12 rows / 9 titles | Promotion, free edition, or missing encoded as zero | Retained and flagged |
| Truncated text | 14 rows | Upstream listing/export truncation | Flagged; not guessed |
| Price IQR outliers | 31 | Manuals, box sets, and premium editions | Retained; use medians |
| Review IQR outliers | 17 | Viral/high-engagement books | Retained; use log scale |
| Rating IQR outliers | 21 | Lower-rated bestsellers in a compressed scale | Retained |

## Insights

### 1. Persistence identifies evergreen demand

Two titles appear in 10 distinct years:

- *The 5 Love Languages: The Secret to Love that Lasts*
- *Publication Manual of the American Psychological Association, 6th Edition*

`StrengthsFinder 2.0` follows with nine years. Long-running titles deserve a separate evergreen strategy from one-year breakouts.

### 2. Author breadth and title persistence are different

Jeff Kinney leads author list presence with 12 records across 12 unique titles, showing portfolio breadth. The American Psychological Association has 10 records from one persistent title. Ranking authors with one raw count would hide this strategic difference.

### 3. Genre leadership depends on the metric

| Metric | Fiction | Non Fiction |
|---|---:|---:|
| List records | 240 | 310 |
| Canonical titles | 160 | 190 |
| Average rating | 4.65 | 4.60 |
| Median reviews | 10,922 | 6,346 |
| Median price | $9 | $12 |

Non Fiction dominates list presence in 10 of 11 years, while Fiction leads in 2014. Fiction shows stronger median review engagement and a slightly higher average rating; Non Fiction commands a higher typical price.

### 4. Popularity and satisfaction are not interchangeable

The Spearman correlation between rating and reviews is `0.20`, a weak positive association. A prominent example is *The Girl on the Train*: 79,446 reviews with a 4.1 rating. Acquisition and promotion decisions should therefore use both reach and satisfaction.

### 5. Higher price does not imply higher user satisfaction

The Spearman price–rating association is `-0.23`, weakly negative. This is not a causal result. Premium manuals and box sets are structurally different from lower-priced trade books, so genre and product-format segmentation are essential.

### 6. The apparent yearly review trend is not reliable

The median review count rises from 3,780 in 2009 to 11,185 in 2019, but review counts are almost always copied across repeat appearances. This pattern may reflect a later snapshot attached to historical rows. It must not be described as annual review growth.

### 7. Ratings improve across the list composition

The annual average rating increases from 4.58 in 2009 to 4.74 in 2019. This describes the mix of books present in each year's list; it does not prove that individual books improved over time.

## Recommendations

1. Maintain an evergreen portfolio view based on distinct years of list presence.
2. Use a two-factor acquisition matrix: rating for satisfaction and reviews for reach.
3. Benchmark Fiction and Non Fiction separately for price and engagement.
4. Validate all zero-price and same-title/year records against edition or ISBN data before price modeling.
5. Prefer medians and log-scaled review charts because price and engagement are right-skewed.
6. Collect rank, capture date, units sold, revenue, ISBN, format, and promotion fields before making commercial or causal claims.

## Limitations

- No sales volume, revenue, margin, or conversion data.
- No bestseller rank within each annual list.
- No review timestamp; reviews appear to be a snapshot.
- No ISBN, edition, or format field.
- Price zero is ambiguous.
- Titles and authors are occasionally truncated in the source.
- The source and license metadata must be confirmed before public redistribution.

