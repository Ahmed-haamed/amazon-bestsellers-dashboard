"""Rebuild versioned cleaned outputs from the bundled raw CSV."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from src.data_pipeline import clean_amazon_data  # noqa: E402


raw_path = PROJECT_ROOT / "data" / "raw" / "amazon_bestsellers.csv"
output_dir = PROJECT_ROOT / "data" / "processed"
output_dir.mkdir(parents=True, exist_ok=True)

raw = pd.read_csv(raw_path, encoding="utf-8-sig")
result = clean_amazon_data(raw)

result.data.to_csv(
    output_dir / "amazon_bestsellers_clean.csv", index=False, encoding="utf-8-sig"
)
result.change_log.to_csv(
    output_dir / "cleaning_change_log.csv", index=False, encoding="utf-8-sig"
)
result.issues.to_csv(
    output_dir / "data_quality_issues.csv", index=False, encoding="utf-8-sig"
)
(output_dir / "data_quality_summary.json").write_text(
    json.dumps(result.summary, indent=2, ensure_ascii=False), encoding="utf-8"
)

print(
    f"Built {len(result.data):,} clean rows, {result.summary['unique_titles']:,} "
    f"canonical titles, and {len(result.change_log):,} audited cell changes."
)

