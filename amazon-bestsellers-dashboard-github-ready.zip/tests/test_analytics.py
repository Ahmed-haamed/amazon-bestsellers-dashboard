"""Tests that protect the dashboard's analytical grain and metrics."""

from pathlib import Path
import unittest

import pandas as pd

from src.analytics import book_summary, correlation_matrix, genre_summary
from src.data_pipeline import clean_amazon_data


ROOT = Path(__file__).resolve().parents[1]


class AnalyticsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        raw = pd.read_csv(
            ROOT / "data" / "raw" / "amazon_bestsellers.csv",
            encoding="utf-8-sig",
        )
        cls.data = clean_amazon_data(raw).data

    def test_book_summary_counts_distinct_years_not_duplicate_editions(self) -> None:
        books = book_summary(self.data)
        the_help = books.loc[books["title"].eq("The Help")].iloc[0]
        self.assertEqual(the_help["list_records"], 4)
        self.assertEqual(the_help["years_on_list"], 3)

    def test_genre_counts_reconcile_to_clean_rows(self) -> None:
        genres = genre_summary(self.data)
        self.assertEqual(genres["list_records"].sum(), len(self.data))
        self.assertEqual(set(genres["genre"]), {"Fiction", "Non Fiction"})

    def test_correlations_are_bounded(self) -> None:
        correlations = correlation_matrix(self.data)
        self.assertEqual(correlations.shape, (3, 3))
        self.assertGreaterEqual(correlations.to_numpy().min(), -1)
        self.assertLessEqual(correlations.to_numpy().max(), 1)


if __name__ == "__main__":
    unittest.main()

