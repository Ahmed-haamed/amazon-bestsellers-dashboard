"""Regression tests for the cleaning rules applied to the bundled dataset."""

from pathlib import Path
import unittest

import pandas as pd

from src.data_pipeline import clean_amazon_data


ROOT = Path(__file__).resolve().parents[1]


class DataPipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        raw = pd.read_csv(
            ROOT / "data" / "raw" / "amazon_bestsellers.csv",
            encoding="utf-8-sig",
        )
        cls.result = clean_amazon_data(raw)

    def test_cleaning_preserves_meaningful_list_records(self) -> None:
        self.assertEqual(self.result.summary["source_rows"], 550)
        self.assertEqual(self.result.summary["clean_rows"], 550)
        self.assertEqual(self.result.summary["removed_rows"], 0)
        self.assertEqual(self.result.summary["title_year_duplicate_extra"], 3)
        self.assertEqual(self.result.summary["title_year_duplicate_affected"], 6)

    def test_canonical_entities_and_text_repairs(self) -> None:
        data = self.result.data
        self.assertEqual(data["title"].nunique(), 350)
        self.assertEqual(data["author"].nunique(), 246)
        self.assertNotIn("J. K. Rowling", set(data["author"]))
        self.assertNotIn("George R. R. Martin", set(data["author"]))
        self.assertEqual(
            data["title"]
            .eq("The 5 Love Languages: The Secret to Love that Lasts")
            .sum(),
            10,
        )
        self.assertFalse(
            any(
                0x80 <= ord(character) <= 0x9F
                for text in data[["title", "author", "genre"]].stack()
                for character in text
            )
        )

    def test_quality_flags_match_known_source_conditions(self) -> None:
        self.assertEqual(self.result.summary["completeness_pct"], 100.0)
        self.assertEqual(self.result.summary["zero_price_rows"], 12)
        self.assertEqual(self.result.summary["price_outlier_rows"], 31)
        self.assertEqual(self.result.summary["review_outlier_rows"], 17)
        self.assertGreaterEqual(
            self.result.summary["constant_review_repeat_titles"], 90
        )
        self.assertGreaterEqual(len(self.result.change_log), 10)


if __name__ == "__main__":
    unittest.main()

